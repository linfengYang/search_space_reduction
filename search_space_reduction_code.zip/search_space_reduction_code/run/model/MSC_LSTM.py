import torch
import torch.nn as nn


class MultiScaleConvStem(nn.Module):
    # 输入：[B, input_channels, T]
    # 输出：[B, hidden_dim, T]

    def __init__(
        self,
        input_channels,
        stem_dim,
        hidden_dim,
        dropout=0.1
    ):
        super().__init__()

        # 小尺度卷积分支
        self.branch_3 = nn.Sequential(
            nn.Conv1d(
                input_channels,
                stem_dim,
                kernel_size=3,
                padding=1
            ),
            nn.GroupNorm(
                num_groups=choose_group_num(stem_dim),
                num_channels=stem_dim
            ),
            nn.GELU()
        )

        # 大尺度卷积分支
        self.branch_5 = nn.Sequential(
            nn.Conv1d(
                input_channels,
                stem_dim,
                kernel_size=5,
                padding=2
            ),
            nn.GroupNorm(
                num_groups=choose_group_num(stem_dim),
                num_channels=stem_dim
            ),
            nn.GELU()
        )

        # 融合两种尺度的卷积特征
        self.fusion = nn.Sequential(
            nn.Conv1d(
                stem_dim * 2,
                hidden_dim,
                kernel_size=1
            ),
            nn.GroupNorm(
                num_groups=choose_group_num(hidden_dim),
                num_channels=hidden_dim
            ),
            nn.GELU(),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        # [B, stem_dim, T]
        h3 = self.branch_3(x)

        # [B, stem_dim, T]
        h5 = self.branch_5(x)

        # [B, stem_dim * 2, T]
        h = torch.cat([h3, h5], dim=1)

        # [B, hidden_dim, T]
        h = self.fusion(h)

        return h


class BiLSTMEncoder(nn.Module):
    # 输入：[B, hidden_dim, T]

    # 输出：[B, hidden_dim, T]

    def __init__(
        self,
        hidden_dim,
        num_layers=1,
        dropout=0.1
    ):
        super().__init__()

        if hidden_dim % 2 != 0:
            raise ValueError(
                "hidden_dim 必须是偶数，"
                "因为双向 LSTM 的两个方向各使用一半隐藏维度。"
            )

        self.lstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim // 2,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if num_layers > 1 else 0.0
        )

        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(hidden_dim)

    def forward(self, x):
        # 转换为 LSTM 所需格式
        # [B, hidden_dim, T] -> [B, T, hidden_dim]
        sequence = x.transpose(1, 2)

        residual = sequence

        # [B, T, hidden_dim]
        sequence, _ = self.lstm(sequence)

        sequence = self.dropout(sequence)

        # 残差连接
        sequence = self.norm(
            sequence + residual
        )

        # 恢复卷积格式
        # [B, T, hidden_dim] -> [B, hidden_dim, T]
        sequence = sequence.transpose(1, 2).contiguous()

        return sequence


class GlobalFusionHead(nn.Module):
    # 输入：[B, hidden_dim, T]
    # 输出：[B, num_units, T]

    def __init__(
        self,
        hidden_dim,
        num_units,
        dropout=0.1
    ):
        super().__init__()

        self.fusion = nn.Sequential(
            nn.Conv1d(
                hidden_dim * 3,
                hidden_dim,
                kernel_size=1
            ),
            nn.GroupNorm(
                num_groups=choose_group_num(hidden_dim),
                num_channels=hidden_dim
            ),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        self.out = nn.Conv1d(
            hidden_dim,
            num_units,
            kernel_size=1
        )

    def forward(self, h):

        T = h.size(2)

        # 全局平均特征
        h_avg = torch.mean(
            h,
            dim=2,
            keepdim=True
        )

        # 全局最大特征
        h_max = torch.max(
            h,
            dim=2,
            keepdim=True
        )[0]

        # 将全局特征复制到每个时段
        h_avg = h_avg.expand(
            -1,
            -1,
            T
        )

        h_max = h_max.expand(
            -1,
            -1,
            T
        )

        # 局部特征 + 平均特征 + 最大特征
        h_cat = torch.cat(
            [h, h_avg, h_max],
            dim=1
        )

        # [B, hidden_dim, T]
        h_fuse = self.fusion(h_cat)

        # [B, num_units, T]
        logits = self.out(h_fuse)

        return logits


class _MSCLSTMBase(nn.Module):
    """
    MSC-LSTM：

    1. Multi-Scale Convolution
    2. Bidirectional LSTM
    3. Global Feature Fusion
    """

    def __init__(
        self,
        num_units,
        input_channels,
        max_input_channels,
        stem_dim,
        hidden_dim,
        lstm_layers=1,
        dropout=0.1
    ):
        super().__init__()

        if input_channels > max_input_channels:
            raise ValueError(
                f"当前模型最多支持 input_channels <= "
                f"{max_input_channels}，"
                f"但传入的是 {input_channels}"
            )

        if hidden_dim % 2 != 0:
            raise ValueError(
                "hidden_dim 必须是偶数。"
            )

        self.num_units = num_units
        self.input_channels = input_channels

        # 第一部分：多尺度卷积
        self.feature_extractor = MultiScaleConvStem(
            input_channels=input_channels,
            stem_dim=stem_dim,
            hidden_dim=hidden_dim,
            dropout=dropout
        )

        # 第二部分：双向 LSTM
        self.temporal_encoder = BiLSTMEncoder(
            hidden_dim=hidden_dim,
            num_layers=lstm_layers,
            dropout=dropout
        )

        # 第三部分：全局融合和输出
        self.output_head = GlobalFusionHead(
            hidden_dim=hidden_dim,
            num_units=num_units,
            dropout=dropout
        )

    def forward(self, x):
        # 输入：[B, input_channels, T]
        # 输出：[B, num_units, T]

        # 多尺度局部特征提取
        h = self.feature_extractor(x)

        # LSTM 时序特征提取
        h = self.temporal_encoder(h)

        # 局部－全局特征融合与输出
        logits = self.output_head(h)

        return logits

class MSCLSTM_N(_MSCLSTMBase):
    """
    Nano：
    input_channels <= 64
    """

    def __init__(
        self,
        num_units,
        input_channels,
        dropout=0.1
    ):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=64,
            stem_dim=16,
            hidden_dim=32,
            lstm_layers=1,
            dropout=dropout
        )


class MSCLSTM_S(_MSCLSTMBase):
    """
    Small：
    input_channels <= 128
    """

    def __init__(
        self,
        num_units,
        input_channels,
        dropout=0.1
    ):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=128,
            stem_dim=32,
            hidden_dim=64,
            lstm_layers=1,
            dropout=dropout
        )


class MSCLSTM_M(_MSCLSTMBase):
    """
    Medium：
    input_channels <= 256
    """

    def __init__(
        self,
        num_units,
        input_channels,
        dropout=0.1
    ):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=256,
            stem_dim=64,
            hidden_dim=128,
            lstm_layers=1,
            dropout=dropout
        )


class MSCLSTM_L(_MSCLSTMBase):
    """
    Large：
    input_channels <= 384
    """

    def __init__(
        self,
        num_units,
        input_channels,
        dropout=0.1
    ):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=384,
            stem_dim=128,
            hidden_dim=256,
            lstm_layers=2,
            dropout=dropout
        )


class MSCLSTM_U(_MSCLSTMBase):
    """
    Ultra：
    input_channels <= 1296
    """

    def __init__(
        self,
        num_units,
        input_channels,
        dropout=0.10
    ):
        super().__init__(
            num_units=num_units,
            input_channels=input_channels,
            max_input_channels=1296,
            stem_dim=256,
            hidden_dim=512,
            lstm_layers=2,
            dropout=dropout
        )

class TemporalSmoothL2Loss(nn.Module):
    def __init__(self, apply_sigmoid=True):
        super().__init__()
        self.apply_sigmoid = apply_sigmoid

    def forward(self, logits, target=None):
        if self.apply_sigmoid:
            prob = torch.sigmoid(logits)
        else:
            prob = logits

        diff = prob[:, :, 1:] - prob[:, :, :-1]

        loss = torch.mean(diff ** 2)

        return loss

class BCEW_TS_Loss(nn.Module):
    def __init__(self, lambda_smooth=0.01, pos_weight=None):
        super().__init__()

        self.bce = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        self.smooth = MaskedTemporalSmoothLoss(apply_sigmoid=True)
        self.lambda_smooth = lambda_smooth

    def forward(self, logits, target):
        loss_bce = self.bce(logits, target.float())
        loss_smooth = self.smooth(logits, target.float())

        loss = loss_bce + self.lambda_smooth * loss_smooth

        return loss