import torch
import torch.nn as nn


# ============================================================
# 不同规模系统配置
# ============================================================

SYSTEM_CONFIGS = {
# ========================================================
    # 6机组，30节点
    # u:     [B, 6, 24]
    # theta: [B, 31, 24]
    # output_dim = 6 * 24 = 144
    # ========================================================
    6: {
        "num_nodes": 30,
        "theta_dim": 31,

        # W 的动态基数量
        "basis_rank": 2,

        # Encoder 部分
        "encoder_unit_dim": 16,
        "encoder_hidden_dim": 32,

        # 负荷主干宽度
        "load_feature_dim": 16,

        # 正则强度
        "dropout": 0.01

    },
    # ========================================================
    # 54机组，118节点
    # u:     [B, 54, 24]
    # theta: [B, 119, 24]
    # output_dim = 54 * 24 = 1296
    # ========================================================
    54: {
        "num_nodes": 118,
        "theta_dim": 119,

        # W 的动态基数量
        "basis_rank": 4,

        # Encoder 部分
        "encoder_unit_dim": 64,
        "encoder_hidden_dim": 128,

        # 负荷主干宽度
        "load_feature_dim": 64,

        # 正则强度
        "dropout": 0.05
    },

    # ========================================================
    # 108机组，236节点
    # u:     [B, 108, 24]
    # theta: [B, 237, 24]
    # output_dim = 108 * 24 = 2592
    # ========================================================
    108: {
        "num_nodes": 236,
        "theta_dim": 237,
        "basis_rank": 8,

        "encoder_unit_dim": 128,
        "encoder_hidden_dim": 256,

        "load_feature_dim": 96,

        "dropout": 0.08
    },

    # ========================================================
    # 162机组，354节点
    # u:     [B, 162, 24]
    # theta: [B, 355, 24]
    # output_dim = 162 * 24 = 3888
    # ========================================================
    162: {
        "num_nodes": 354,
        "theta_dim": 355,
        "basis_rank": 8,

        "encoder_unit_dim": 128,
        "encoder_hidden_dim": 256,

        "load_feature_dim": 128,

        "dropout": 0.10
    },
    # ========================================================
    # 486机组，1062节点
    # u:     [B, 486, 24]
    # theta: [B, 1063, 24]
    # output_dim = 486 * 24 = 11664
    # ========================================================
    486: {
        "num_nodes": 1062,
        "theta_dim": 1063,
        "basis_rank": 16,

        "encoder_unit_dim": 256,
        "encoder_hidden_dim": 512,

        "load_feature_dim": 256,

        "dropout": 0.10
    }

}


# ============================================================
# 时间残差卷积模块
# ============================================================

class TemporalResidualBlock(nn.Module):
    """
    输入:
        x: [B, C, T]

    输出:
        x: [B, C, T]
    """

    def __init__(
        self,
        channels,
        dilation=1,
        dropout=0.1
    ):
        super().__init__()

        self.norm1 = nn.GroupNorm(
            num_groups=1,
            num_channels=channels
        )

        self.depthwise_conv = nn.Conv1d(
            in_channels=channels,
            out_channels=channels,
            kernel_size=3,
            padding=dilation,
            dilation=dilation,
            groups=channels,
            bias=False
        )

        self.gate_projection = nn.Conv1d(
            in_channels=channels,
            out_channels=2 * channels,
            kernel_size=1
        )

        self.dropout1 = nn.Dropout(dropout)

        self.norm2 = nn.GroupNorm(
            num_groups=1,
            num_channels=channels
        )

        self.channel_ffn = nn.Sequential(
            nn.Conv1d(
                in_channels=channels,
                out_channels=2 * channels,
                kernel_size=1
            ),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Conv1d(
                in_channels=2 * channels,
                out_channels=channels,
                kernel_size=1
            ),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        residual = x

        y = self.norm1(x)
        y = self.depthwise_conv(y)
        y = self.gate_projection(y)

        value, gate = torch.chunk(
            y,
            chunks=2,
            dim=1
        )

        y = value * torch.sigmoid(gate)
        y = self.dropout1(y)

        x = residual + y

        x = x + self.channel_ffn(
            self.norm2(x)
        )

        return x


# ============================================================
# Encoder：高效机组状态编码器
# ============================================================

class UnitTemporalEncoder(nn.Module):
    """
    对每台机组的 24h 开关机序列进行共享编码。

    输入:
        u: [B, G, T]

    输出:
        unit_feature: [B, G, unit_dim]
    """

    def __init__(
        self,
        horizon=24,
        unit_dim=64,
        dropout=0.1
    ):
        super().__init__()

        self.horizon = horizon
        self.unit_dim = unit_dim

        self.temporal_net = nn.Sequential(
            nn.Conv1d(
                in_channels=1,
                out_channels=32,
                kernel_size=3,
                padding=1
            ),
            nn.GELU(),

            nn.Conv1d(
                in_channels=32,
                out_channels=64,
                kernel_size=3,
                padding=1
            ),
            nn.GELU(),

            nn.Conv1d(
                in_channels=64,
                out_channels=64,
                kernel_size=3,
                padding=1
            ),
            nn.GELU(),

            nn.AdaptiveAvgPool1d(1)
        )

        self.projection = nn.Sequential(
            nn.Linear(64, unit_dim),
            nn.LayerNorm(unit_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

    def forward(self, u):
        if u.ndim != 3:
            raise ValueError(
                f"UnitTemporalEncoder 输入应为 [B, G, T]，当前为 {tuple(u.shape)}"
            )

        batch_size, num_units, horizon = u.shape

        if horizon != self.horizon:
            raise ValueError(
                f"时间维应为 {self.horizon}，当前为 {horizon}"
            )

        # [B, G, T] -> [B*G, 1, T]
        x = u.reshape(
            batch_size * num_units,
            1,
            horizon
        )

        # [B*G, 64, 1]
        x = self.temporal_net(x)

        # [B*G, 64]
        x = x.squeeze(-1)

        # [B*G, unit_dim]
        x = self.projection(x)

        # [B, G, unit_dim]
        x = x.reshape(
            batch_size,
            num_units,
            self.unit_dim
        )

        return x


class Encoder(nn.Module):
    """
    高效机组组合编码器。

    输入:
        u: [B, G, T] 或 [B, G*T]

    输出:
        z: [B, latent_dim]
    """

    def __init__(
        self,
        num_units,
        horizon,
        latent_dim,
        unit_dim=64,
        hidden_dim=128,
        dropout=0.1
    ):
        super().__init__()

        self.num_units = num_units
        self.horizon = horizon
        self.latent_dim = latent_dim

        self.unit_encoder = UnitTemporalEncoder(
            horizon=horizon,
            unit_dim=unit_dim,
            dropout=dropout
        )

        self.unit_attention = nn.Sequential(
            nn.LayerNorm(unit_dim),
            nn.Linear(unit_dim, 1)
        )

        self.fusion = nn.Sequential(
            nn.Linear(3 * unit_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Linear(hidden_dim, latent_dim)
        )

        self._initialize_output_layer()

    def _initialize_output_layer(self):
        output_layer = self.fusion[-1]

        nn.init.xavier_uniform_(
            output_layer.weight,
            gain=0.2
        )

        nn.init.zeros_(
            output_layer.bias
        )

    def forward(self, u):
        if u.ndim == 2:
            batch_size = u.size(0)

            expected_dim = self.num_units * self.horizon

            if u.size(1) != expected_dim:
                raise ValueError(
                    f"Encoder 输入维度应为 {expected_dim}，当前为 {u.size(1)}"
                )

            u = u.reshape(
                batch_size,
                self.num_units,
                self.horizon
            )

        if u.ndim != 3:
            raise ValueError(
                f"Encoder 输入必须为 [B, G, T] 或 [B, G*T]，当前为 {tuple(u.shape)}"
            )

        if u.size(1) != self.num_units:
            raise ValueError(
                f"机组数应为 {self.num_units}，当前为 {u.size(1)}"
            )

        if u.size(2) != self.horizon:
            raise ValueError(
                f"时间维应为 {self.horizon}，当前为 {u.size(2)}"
            )

        # [B, G, unit_dim]
        unit_feature = self.unit_encoder(
            u.float()
        )

        # 均值池化
        mean_feature = unit_feature.mean(dim=1)

        # 最大池化
        max_feature = unit_feature.max(dim=1).values

        # 注意力池化
        attention_score = self.unit_attention(
            unit_feature
        )

        attention_weight = torch.softmax(
            attention_score,
            dim=1
        )

        attention_feature = torch.sum(
            attention_weight * unit_feature,
            dim=1
        )

        feature = torch.cat(
            [
                mean_feature,
                max_feature,
                attention_feature,
            ],
            dim=-1
        )

        z_raw = self.fusion(feature)

        # 将隐变量限制在 (-1, 1)
        # z = torch.tanh(z_raw)

        # 将隐变量限制在 (0, 1)
        z = torch.sigmoid(z_raw)

        return z


# ============================================================
# 负荷主干网络
# ============================================================

class LoadBackbone(nn.Module):
    """
    高效负荷特征提取器。

    输入:
        theta: [B, N+1, T]

    输出:
        feature: [B, feature_dim]
    """

    def __init__(
        self,
        theta_dim,
        horizon=24,
        d_model=96,
        feature_dim=128,
        dropout=0.1
    ):
        super().__init__()

        self.theta_dim = theta_dim
        self.horizon = horizon
        self.d_model = d_model
        self.feature_dim = feature_dim

        self.input_norm = nn.LayerNorm(theta_dim)

        self.channel_projection = nn.Sequential(
            nn.Conv1d(
                in_channels=theta_dim,
                out_channels=d_model,
                kernel_size=1,
                bias=False
            ),
            nn.GroupNorm(
                num_groups=1,
                num_channels=d_model
            ),
            nn.GELU(),
        )

        self.temporal_blocks = nn.Sequential(
            TemporalResidualBlock(
                channels=d_model,
                dilation=1,
                dropout=dropout
            ),
            TemporalResidualBlock(
                channels=d_model,
                dilation=2,
                dropout=dropout
            ),
            TemporalResidualBlock(
                channels=d_model,
                dilation=4,
                dropout=dropout
            )
        )

        self.attention_pool = nn.Conv1d(
            in_channels=d_model,
            out_channels=1,
            kernel_size=1
        )

        self.output_head = nn.Sequential(
            nn.Linear(d_model, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

    def forward(self, theta):
        if theta.ndim != 3:
            raise ValueError(
                f"theta 应为 [B, N+1, T]，当前为 {tuple(theta.shape)}"
            )

        if theta.size(1) != self.theta_dim:
            raise ValueError(
                f"theta 第二维应为 {self.theta_dim}，当前为 {theta.size(1)}"
            )

        if theta.size(2) != self.horizon:
            raise ValueError(
                f"theta 时间维应为 {self.horizon}，当前为 {theta.size(2)}"
            )

        # [B, N+1, T] -> [B, T, N+1]
        x = theta.transpose(1, 2)

        # 每个时刻对所有节点/负荷通道归一化
        x = self.input_norm(x)

        # [B, T, N+1] -> [B, N+1, T]
        x = x.transpose(1, 2)

        # [B, d_model, T]
        x = self.channel_projection(x)

        # [B, d_model, T]
        x = self.temporal_blocks(x)

        # [B, 1, T]
        attention_score = self.attention_pool(x)

        attention_weight = torch.softmax(
            attention_score,
            dim=-1
        )

        # [B, d_model]
        feature = torch.sum(
            attention_weight * x,
            dim=-1
        )

        # [B, feature_dim]
        feature = self.output_head(feature)

        return feature



# ============================================================
# 低秩动态参数生成网络
# ============================================================

class ParamGenerator(nn.Module):
    """
    使用低秩动态参数生成网络生成实例相关 W 和 b。

    输出:
        weights: [B, latent_dim, output_dim]
        biases:  [B, output_dim]
    """

    def __init__(
        self,
        theta_dim,
        horizon,
        latent_dim,
        output_dim,
        basis_rank,
        feature_dim=128,
        dropout=0.1
    ):
        super().__init__()

        self.latent_dim = latent_dim
        self.output_dim = output_dim
        self.basis_rank = basis_rank

        self.weight_backbone = LoadBackbone(
            theta_dim=theta_dim,
            horizon=horizon,
            d_model=feature_dim,
            feature_dim=feature_dim,
            dropout=dropout
        )

        bias_feature_dim = max(32, feature_dim // 2)

        self.bias_backbone = LoadBackbone(
            theta_dim=theta_dim,
            horizon=horizon,
            d_model=bias_feature_dim,
            feature_dim=bias_feature_dim,
            dropout=dropout
        )

        self.coeff_head = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),
            nn.LayerNorm(feature_dim),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Linear(
                feature_dim,
                basis_rank
            )
        )

        self.bias_head = nn.Sequential(
            nn.Linear(bias_feature_dim, bias_feature_dim),
            nn.LayerNorm(bias_feature_dim),
            nn.GELU(),
            nn.Dropout(dropout),

            nn.Linear(
                bias_feature_dim,
                output_dim
            )
        )

        # 基础解空间参数
        self.base_weight = nn.Parameter(
            torch.randn(
                latent_dim,
                output_dim
            ) * 0.01
        )

        # 动态低秩扰动基
        self.weight_basis = nn.Parameter(
            torch.randn(
                basis_rank,
                latent_dim,
                output_dim
            ) * 0.01
        )

        self._initialize_output_layers()

    def forward(self, theta):

        batch_size = theta.size(0)

        weight_feature = self.weight_backbone(theta)
        bias_feature = self.bias_backbone(theta)

        coeff = self.coeff_head(
            weight_feature
        )

        # coeff = torch.tanh(coeff)
        coeff = torch.nn.functional.softsign(coeff)
        # print(coeff)

        dynamic_delta = torch.einsum(
            "br,rlo->blo",
            coeff,
            self.weight_basis
        )

        weights = (
            self.base_weight.unsqueeze(0)
            +
            dynamic_delta
        )

        biases = self.bias_head(
            bias_feature
        )

        return weights, biases


# ============================================================
# 多专家解码器
# ============================================================

class DynamicDecoder(nn.Module):
    """
    动态解码器。

    根据负荷生成实例相关参数 W(theta), b(theta)。
    """

    def __init__(
        self,
        theta_dim,
        horizon,
        latent_dim,
        output_dim,
        basis_rank,
        feature_dim,
        dropout
    ):
        super().__init__()

        self.param_generator = ParamGenerator(
            theta_dim=theta_dim,
            horizon=horizon,
            latent_dim=latent_dim,
            output_dim=output_dim,
            basis_rank=basis_rank,
            feature_dim=feature_dim,
            dropout=dropout
        )

    def forward(
        self,
        z,
        theta
    ):

        weights, biases = self.param_generator(theta)

        logits = torch.einsum(
            "bl,blo->bo",
            z,
            weights
        ) + biases

        return logits



# ============================================================
# 完整模型
# ============================================================

class LCD_AE(nn.Module):
    def __init__(
        self,
        num_units,
        latent_dim,
        horizon=24,
        theta_dim=None,
        basis_rank=None,
        dropout=None,
        encoder_unit_dim=None,
        encoder_hidden_dim=None,
        load_feature_dim=None
    ):
        super().__init__()

        if num_units not in SYSTEM_CONFIGS:
            raise ValueError(
                f"当前仅支持 54、108、162 机组系统，当前 num_units={num_units}"
            )

        if latent_dim <= 0:
            raise ValueError(
                "latent_dim 必须大于 0"
            )

        config = SYSTEM_CONFIGS[num_units]

        if theta_dim is None:
            theta_dim = config["theta_dim"]

        expected_theta_dim = config["theta_dim"]

        if theta_dim != expected_theta_dim:
            raise ValueError(
                f"{num_units} 机组系统对应 theta_dim 应为 {expected_theta_dim}，"
                f"当前传入 {theta_dim}"
            )

        if basis_rank is None:
            basis_rank = config["basis_rank"]

        if dropout is None:
            dropout = config["dropout"]

        if encoder_unit_dim is None:
            encoder_unit_dim = config["encoder_unit_dim"]

        if encoder_hidden_dim is None:
            encoder_hidden_dim = config["encoder_hidden_dim"]

        if load_feature_dim is None:
            load_feature_dim = config["load_feature_dim"]


        self.num_units = num_units
        self.horizon = horizon
        self.theta_dim = theta_dim
        self.latent_dim = latent_dim
        self.basis_rank = basis_rank

        self.output_dim = (
            num_units * horizon
        )

        self.encoder = Encoder(
            num_units=num_units,
            horizon=horizon,
            latent_dim=latent_dim,
            unit_dim=encoder_unit_dim,
            hidden_dim=encoder_hidden_dim,
            dropout=dropout
        )

        self.decoder = DynamicDecoder(
            theta_dim=theta_dim,
            horizon=horizon,
            latent_dim=latent_dim,
            output_dim=self.output_dim,
            basis_rank=basis_rank,
            feature_dim=load_feature_dim,
            dropout=dropout
        )

    def forward(
        self,
        u,
        theta
    ):
        """
        u:
            [B, G, T] 或 [B, G*T]

        theta:
            [B, N+1, T]
        """

        input_is_3d = (
            u.ndim == 3
        )

        batch_size = u.size(0)

        # [B, latent_dim]
        z = self.encoder(u)
        u_hat = self.decoder(
            z=z,
            theta=theta
        )


        if input_is_3d:
            u_hat = u_hat.reshape(
                batch_size,
                self.num_units,
                self.horizon
            )

        return u_hat

    @torch.no_grad()
    def generate_effective_parameters(
        self,
        theta
    ):
        """
        根据 theta 生成在线等效参数。

        返回:
            effective_weight:
                [B, latent_dim, output_dim]

            effective_bias:
                [B, output_dim]

            alpha:
                [B, num_experts]

        最终关系:
            logits = z @ effective_weight + effective_bias
        """

        original_training_state = self.training

        self.eval()
        effective_weight, effective_bias = (
            self.decoder.param_generator(theta)
        )

        return (
            effective_weight,
            effective_bias
        )



# ============================================================
# 损失函数
# ============================================================

class TemporalSmoothL2Loss(nn.Module):
    def __init__(
        self,
        apply_sigmoid=True
    ):
        super().__init__()

        self.apply_sigmoid = apply_sigmoid

    def forward(
        self,
        logits,
        target=None
    ):
        if self.apply_sigmoid:
            prob = torch.sigmoid(logits)
        else:
            prob = logits

        diff = (
            prob[:, :, 1:]
            - prob[:, :, :-1]
        )

        loss = torch.mean(
            diff ** 2
        )

        return loss



class BCEW_TS_Loss(nn.Module):
    def __init__(
        self,
        lambda_smooth=0.01,
        pos_weight=None,
    ):
        super().__init__()

        self.bce = nn.BCEWithLogitsLoss(
            pos_weight=pos_weight
        )

        self.smooth = MaskedTemporalSmoothLoss(
            apply_sigmoid=True
        )

        self.lambda_smooth = lambda_smooth

    def forward(
        self,
        logits,
        target,
    ):
        loss_bce = self.bce(
            logits,
            target.float()
        )

        loss_smooth = self.smooth(
            logits,
            target.float()
        )

        loss = (
            loss_bce
            + self.lambda_smooth
            * loss_smooth
        )

        return loss