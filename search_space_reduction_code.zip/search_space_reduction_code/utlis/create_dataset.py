from torch.utils.data import Dataset
import numpy as np
import torch

class UCLoadDataset(Dataset):
    def __init__(self, X_scaled, Y):
        """
        X_scaled: [num_samples, num_nodes + 1, 24]
        Y:        [num_samples, G, 24]
        """
        self.X_scaled = X_scaled.astype(np.float32)
        self.Y = Y.astype(np.float32)

    def __len__(self):
        return len(self.X_scaled)

    def __getitem__(self, idx):
        # x: [num_nodes + 1, 24]
        x = self.X_scaled[idx]

        # y: [G, 24]
        y = self.Y[idx]

        x_tensor = torch.tensor(x, dtype=torch.float32)
        y_tensor = torch.tensor(y, dtype=torch.float32)

        return x_tensor, y_tensor