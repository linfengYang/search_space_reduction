import joblib
from sklearn.preprocessing import StandardScaler
import numpy as np

# 该处理用于节点负荷归一化
def pre_processing_data(X_train, X_val, system_load_scaler_save_dir):

        # 复制，避免修改原始数组
        X_train_processed = X_train.astype(np.float32).copy()
        X_val_processed = X_val.astype(np.float32).copy()

        # 对系统总负荷进行标准化
        # 只用训练集总负荷拟合 StandardScaler
        system_load_scaler = StandardScaler()

        train_system_load = X_train_processed[:, 0, :]  # [num_train, T]
        val_system_load = X_val_processed[:, 0, :]      # [num_val, T]

        train_system_load_shape = train_system_load.shape
        val_system_load_shape = val_system_load.shape

        # 对数据进行flatten
        train_system_load_flat = train_system_load.reshape(-1, 1)
        val_system_load_flat = val_system_load.reshape(-1, 1)

        # 训练集 fit，验证/测试只 transform
        X_train_processed[:, 0, :] = system_load_scaler.fit_transform(
            train_system_load_flat
        ).reshape(train_system_load_shape)

        X_val_processed[:, 0, :] = system_load_scaler.transform(
            val_system_load_flat
        ).reshape(val_system_load_shape)

        # 对节点负荷占比进行归一化
        train_nodal_load = X_train_processed[:, 1:, :]  # [num_train, N, T]
        val_nodal_load = X_val_processed[:, 1:, :]  # [num_val, N, T]

        hourly_sum_train = train_nodal_load.sum(axis=1, keepdims=True)
        X_train_processed[:, 1:, :] = train_nodal_load / hourly_sum_train

        hourly_sum_val = val_nodal_load.sum(axis=1, keepdims=True)
        X_val_processed[:, 1:, :] = val_nodal_load / hourly_sum_val

        joblib.dump(system_load_scaler, system_load_scaler_save_dir)

        return X_train_processed, X_val_processed

# def pre_processing_data(X_train, X_val, system_load_scaler_save_dir):
#     # 标准化负荷
#
#     # 复制，避免修改原始数组
#     X_train_processed = X_train.astype(np.float32).copy()
#     X_val_processed = X_val.astype(np.float32).copy()
#
#     # 只用训练集总负荷拟合 StandardScaler
#     load_scaler = StandardScaler()
#
#     train_total_load = X_train_processed[:, 0, :]   # [num_train, T]
#     val_total_load = X_val_processed[:, 0, :]      # [num_val, T]
#
#     train_shape = train_total_load.shape
#     val_shape = val_total_load.shape
#
#     # flatten 总负荷
#     train_total_load_flat = train_total_load.reshape(-1, 1)
#     val_total_load_flat = val_total_load.reshape(-1, 1)
#
#     # 训练集 fit，验证/测试只 transform
#     X_train_processed[:, 0, :] = load_scaler.fit_transform(
#         train_total_load_flat
#     ).reshape(train_shape)
#
#     X_val_processed[:, 0, :] = load_scaler.transform(
#         val_total_load_flat
#     ).reshape(val_shape)
#
#     joblib.dump(load_scaler, system_load_scaler_save_dir)
#
#     return X_train_processed, X_val_processed