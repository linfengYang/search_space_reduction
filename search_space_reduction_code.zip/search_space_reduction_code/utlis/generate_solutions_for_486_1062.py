from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp
import os
import sys
from time import time

import numpy as np
try:
    from tqdm.auto import tqdm
except ImportError as exc:
    raise ImportError("缺少 tqdm，请先执行：pip install tqdm") from exc

from solver.DC_SCUC_Gurobi_model import DC_SCUC_Gurobi_model


# 每个子进程各自保存一份只读的基础数据，避免每个样本都重复序列化和传输。
_WORKER_DATA = None
_WORKER_CONFIG = None


def _silence_worker_console():
    """屏蔽子进程输出，避免 Gurobi 许可证和求解日志破坏主进度条。"""
    sys.stdout.flush()
    sys.stderr.flush()
    null_fd = os.open(os.devnull, os.O_WRONLY)
    try:
        os.dup2(null_fd, 1)
        os.dup2(null_fd, 2)
    finally:
        os.close(null_fd)


def _init_worker(data, config, threads_per_solver):
    """初始化求解进程，设置线程数并关闭各子进程的 Gurobi 控制台日志。"""
    global _WORKER_DATA, _WORKER_CONFIG

    # 必须在首次创建 Gurobi 环境之前执行，否则许可证横幅已经输出。
    _silence_worker_console()

    _WORKER_DATA = data
    _WORKER_CONFIG = dict(config)
    _WORKER_CONFIG["threads_per_solver"] = threads_per_solver

    # 多个算例已经在进程层并行，限制每个算例的内部线程可避免 CPU 过度竞争。
    os.environ["OMP_NUM_THREADS"] = str(threads_per_solver)
    os.environ["MKL_NUM_THREADS"] = str(threads_per_solver)
    try:
        import gurobipy as gp

        # 仅关闭控制台日志，不影响求解过程和返回结果。
        gp.setParam("LogToConsole", 0)
        gp.setParam("Threads", threads_per_solver)
    except Exception as exc:
        print(f"警告：未能设置 Gurobi Threads={threads_per_solver}：{exc}", flush=True)


def _configure_gurobi_model(solver):
    """对求解器类暴露的 Gurobi Model 再次应用日志和线程设置。"""
    for attribute_name in ("m", "model"):
        model = getattr(solver, attribute_name, None)
        if model is None or not hasattr(model, "setParam"):
            continue
        model.setParam("LogToConsole", 0)
        model.setParam("Threads", _WORKER_CONFIG["threads_per_solver"])
        return


def _generate_one_sample(task):
    """生成一个有效样本；完成后该 worker 立即领取队列中的下一个任务。"""
    level_order, sample_order, overall_factor, random_seed = task
    rng = np.random.default_rng(random_seed)

    data = _WORKER_DATA
    G = _WORKER_CONFIG["G"]
    N = _WORKER_CONFIG["N"]
    T = _WORKER_CONFIG["T"]
    L = _WORKER_CONFIG["L"]
    MIPGap = _WORKER_CONFIG["MIPGap"]
    MILP_flag = _WORKER_CONFIG["MILP_flag"]

    system_perturb_ratio = 0.1
    nodal_perturb_ratio = 0.05
    group_perturb_ranges = np.array(
        [[0.86, 0.96], [0.96, 1.06], [1.06, 1.16]], dtype=float
    )

    # 原脚本把 1062 个节点划分成 9 个连续区域，每个区域包含 118 个节点。
    num_regions = 9
    if N % num_regions != 0:
        raise ValueError(f"节点数 N={N} 不能被 {num_regions} 个区域整除。")
    nodes_per_region = N // num_regions

    attempts = 0

    while True:
        attempts += 1

        # 1. 逐时总体扰动：保持原脚本的 ±10% 均匀扰动。
        random_factor1 = rng.uniform(
            low=1 - system_perturb_ratio,
            high=1 + system_perturb_ratio,
            size=T,
        )
        P_D = data["P_D"] * overall_factor * random_factor1

        # 2. 区域分组扰动：9 个区域随机分到低、中、高三个扰动组。
        region = rng.permutation(np.arange(1, num_regions + 1)).reshape(3, 3)
        region_factor = np.ones((N, 1), dtype=float)
        for group_index in range(region.shape[0]):
            for region_index in region[group_index]:
                scale = rng.uniform(
                    low=group_perturb_ranges[group_index, 0],
                    high=group_perturb_ranges[group_index, 1],
                )
                start = (region_index - 1) * nodes_per_region
                end = region_index * nodes_per_region
                region_factor[start:end] = scale

        # 3. 节点级扰动：保持原脚本的 ±5% 均匀扰动。
        random_factor2 = rng.uniform(
            low=1 - nodal_perturb_ratio,
            high=1 + nodal_perturb_ratio,
            size=(N, T),
        )
        nodes_load_perturbed_P = (
            data["nodes_load_P"][:, None] * region_factor * random_factor2
        )
        hourly_sum = nodes_load_perturbed_P.sum(axis=0, keepdims=True)
        nodes_load_percentage_P = nodes_load_perturbed_P / hourly_sum

        DC_SCUC = DC_SCUC_Gurobi_model(
            G,
            N,
            T,
            L,
            data["alpha"],
            data["beta"],
            data["gamma"],
            data["hot_su_cost"],
            data["cold_su_cost"],
            data["min_on"],
            data["min_off"],
            data["cold_su_t"],
            data["P_max"],
            data["P_min"],
            data["ramp_up"],
            data["ramp_down"],
            data["su_ramp"],
            data["sd_ramp"],
            data["unit_init_status"],
            data["T_init"],
            data["node_connections"],
            nodes_load_percentage_P,
            data["lines"],
            data["P_ij_max"],
            data["B_matrix"],
            P_D * 0.01,
            data["P_init"],
            data["unit_bus"],
            data["balance_node"],
            MIPGap,
            MILP_flag,
        )
        _configure_gurobi_model(DC_SCUC)

        result = DC_SCUC.myOptimize()
        u_values = result[0]
        if u_values is not None:
            return (
                level_order,
                sample_order,
                overall_factor,
                attempts,
                np.asarray(P_D),
                np.asarray(nodes_load_perturbed_P),
                np.asarray(u_values),
            )


def load_perturbation(
    data,
    datasize,
    random_seed,
    max_workers,
    threads_per_solver=1,
    progress_desc="总体生成进度",
):
    """
    并行生成数据。

    10 个总体扰动水平分别生成 datasize / 10 个可行样本；若 datasize
    不能被 10 整除则直接报错，防止不同扰动水平的数据量不一致。
    """
    # 用整数构造固定的 10 个连续水平，避免 np.arange 的浮点端点误差。
    overall_levels = np.arange(96, 106, dtype=np.int64) / 100.0
    num_levels = len(overall_levels)
    if datasize < num_levels:
        raise ValueError(f"datasize={datasize} 小于总体扰动水平数 {num_levels}。")
    if datasize % num_levels != 0:
        raise ValueError(
            f"datasize={datasize} 不能被总体扰动水平数 {num_levels} 整除，"
            "无法保证每个总体扰动水平生成同样多的数据。"
        )
    if max_workers < 1:
        raise ValueError("max_workers 必须不小于 1。")
    if threads_per_solver < 1:
        raise ValueError("threads_per_solver 必须不小于 1。")

    samples_per_level = datasize // num_levels

    # 仅打乱固定水平的处理顺序，不再随机遗漏某个总体扰动水平。
    seed_sequence = (
        random_seed
        if isinstance(random_seed, np.random.SeedSequence)
        else np.random.SeedSequence(random_seed)
    )
    level_rng = np.random.default_rng(seed_sequence)
    overall_levels = level_rng.permutation(overall_levels)

    # 每个任务只生成一个有效样本。某个 worker 遇到复杂算例时，其他 worker
    # 仍可不断完成队列中的其他样本，避免一个大数据块长期占用进程。
    level_seeds = seed_sequence.spawn(num_levels)
    sample_seeds_by_level = [
        level_seed.spawn(samples_per_level) for level_seed in level_seeds
    ]
    tasks = []
    # 按样本序号轮流放入 10 个扰动水平，避免任务队列长时间只处理一个水平。
    for sample_order in range(samples_per_level):
        for level_order, level in enumerate(overall_levels):
            tasks.append(
                (
                    level_order,
                    sample_order,
                    float(level),
                    sample_seeds_by_level[level_order][sample_order],
                )
            )

    config = {
        "G": G,
        "N": N,
        "T": T,
        "L": L,
        "MIPGap": 0.0001,
        "MILP_flag": 1,
    }
    worker_count = min(max_workers, len(tasks))
    level_results = {level_order: {} for level_order in range(num_levels)}

    print(
        f"{progress_desc}：总样本数 {datasize}，"
        f"共 {num_levels} 个总体扰动水平，每个水平 {samples_per_level} 个。",
        flush=True,
    )

    # spawn 不继承父进程中的 Gurobi 状态，适合独立创建和求解多个模型。
    mp_context = mp.get_context("spawn")
    with ProcessPoolExecutor(
        max_workers=worker_count,
        mp_context=mp_context,
        initializer=_init_worker,
        initargs=(data, config, threads_per_solver),
    ) as executor, tqdm(
        total=datasize,
        desc=progress_desc,
        unit="个",
        dynamic_ncols=True,
        miniters=1,
        mininterval=0.0,
        smoothing=0.1,
    ) as progress_bar:
        future_to_task = {
            executor.submit(_generate_one_sample, task): (
                task[0],
                task[1],
                task[2],
            )
            for task in tasks
        }
        for future in as_completed(future_to_task):
            expected_level_order, expected_sample_order, level = future_to_task[future]
            try:
                result = future.result()
            except Exception as exc:
                raise RuntimeError(
                    f"总体扰动水平 {level:.2f} 的第 "
                    f"{expected_sample_order + 1} 个样本生成失败。"
                ) from exc

            (
                level_order,
                sample_order,
                _,
                _,
                X_sample,
                nodes_sample,
                Y_sample,
            ) = result
            if (
                level_order != expected_level_order
                or sample_order != expected_sample_order
            ):
                raise RuntimeError("并行任务返回的样本编号不一致。")

            level_results[level_order][sample_order] = (
                X_sample,
                nodes_sample,
                Y_sample,
            )
            # 每完成一个有效样本立即更新一次总体已生成个数。
            progress_bar.update(1)

    # 依次按总体扰动水平和样本编号合并，保证运行结果可复现。
    ordered_results = []
    for level_order in range(num_levels):
        samples = level_results[level_order]
        if len(samples) != samples_per_level:
            raise RuntimeError(
                f"总体扰动水平 {overall_levels[level_order]:.2f} 应生成 "
                f"{samples_per_level} 个样本，实际生成 {len(samples)} 个。"
            )
        ordered_results.extend(samples[i] for i in range(samples_per_level))

    X = np.stack([item[0] for item in ordered_results], axis=0)
    nodes_load_P_all = np.stack([item[1] for item in ordered_results], axis=0)
    Y = np.stack([item[2] for item in ordered_results], axis=0)

    if X.shape[0] != datasize:
        raise RuntimeError(
            f"生成数量校验失败：期望 {datasize}，实际 {X.shape[0]}。"
        )
    return X, nodes_load_P_all, Y


def save_dataset_to_txt(X, nodes_load_P_all, Y, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    for i in range(X.shape[0]):
        file_name = os.path.join(output_dir, f"sample_{i:04d}.txt")
        with open(file_name, "w") as f:
            f.write(" ".join([f"{x:.2f}" for x in X[i]]) + "\n")
            for j in range(nodes_load_P_all.shape[1]):
                f.write(
                    " ".join(
                        [
                            f"{nodes_load_P_all[i, j, t]:.6f}"
                            for t in range(nodes_load_P_all.shape[2])
                        ]
                    )
                    + "\n"
                )
            for unit in range(Y.shape[1]):
                f.write(
                    " ".join(
                        [str(int(Y[i, unit, t])) for t in range(Y.shape[2])]
                    )
                    + "\n"
                )
    print(f"{output_dir} 数据集保存完成！")


if __name__ == "__main__":
    # 系统规模
    G = 486
    N = 1062
    T = 24
    L = 1686

    from utlis.get_486_1062_data import get_data

    data = get_data(
        "/home/huangboyang/Learning-based-optimization/utlis/SCUC1062.txt"
    )

    train_size = 4000
    val_size = 400
    test_size = 400

    # 减少同时运行的大型模型：8 个独立算例 × 每个算例 4 个线程 = 32。
    # 每个 worker 一次只生成一个有效样本，完成后立即从队列领取下一个。
    NUM_WORKERS = min(8, os.cpu_count() or 1)
    THREADS_PER_SOLVER = 4

    # 三个数据集使用相互独立且可复现的随机种子。
    split_seeds = np.random.SeedSequence(2026).spawn(3)

    start = time()
    save_folder = (
        "/home/huangboyang/Learning-based-optimization/dataset/DC_SCUC_486_1062"
    )
    split_specs = [
        ("train", train_size, split_seeds[0]),
        ("val", val_size, split_seeds[1]),
        ("test", test_size, split_seeds[2]),
    ]
    for split_name, split_size, split_seed in split_specs:
        X, nodes_load_P_all, Y = load_perturbation(
            data,
            split_size,
            split_seed,
            NUM_WORKERS,
            THREADS_PER_SOLVER,
            f"{split_name} 总体生成进度",
        )
        save_dataset_to_txt(
            X,
            nodes_load_P_all,
            Y,
            os.path.join(save_folder, split_name),
        )
        # 当前数据划分保存后立即释放，降低后续并行求解时的内存压力。
        del X, nodes_load_P_all, Y

    generation_time = time() - start
    print("数据生成时间：", generation_time)

    txt_path = os.path.join(save_folder, "time.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(f"数据生成时间：{generation_time}\n")
