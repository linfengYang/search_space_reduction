from gurobipy import *
import numpy as np
from collections import defaultdict
import time
import torch

class DC_SCUC_Gurobi_model:
    def __init__(self, G, N, T, L, alpha, beta, gamma, hot_su_cost, cold_su_cost,
        min_on, min_off, cold_su_t, P_max, P_min, ramp_up, ramp_down, su_ramp, sd_ramp,
        unit_init_status, T_init, node_connections, nodes_load_percentage_P, lines, P_ij_max, B_matrix,
        P_D, P_init, unit_bus, balance_node, MIPGap, MILP_flag, W=None, b=None, eta=0, logits=None,
        confidence_weights=None, search_space_reduction=False, reduction1=False, reduction2=False, fallback=False):
        self.m = Model()
        self.m.Params.MIPGap = MIPGap
        self.search_space_reduction = search_space_reduction
        self.reduction1 = reduction1
        self.reduction2 = reduction2
        self.fallback = fallback
        self.reduction1_constr = []
        self.reduction1_constr_info = []
        self.m.Params.Method = 4

        # 创建变量
        u = tupledict()
        for i in range(G):
            for t in range(T):
                u[i, t] = self.m.addVar(vtype=GRB.BINARY, name='u' + '(' + str(i) + ',' + str(t) + ')')

        s = tupledict()
        for i in range(G):
            for t in range(T):
                s[i, t] = self.m.addVar(vtype=GRB.BINARY, name='s' + '(' + str(i) + ',' + str(t) + ')')

        d = tupledict()
        for i in range(G):
            for t in range(T):
                d[i, t] = self.m.addVar(vtype=GRB.BINARY, name='d' + '(' + str(i) + ',' + str(t) + ')')

        S = tupledict()
        for i in range(G):
            for t in range(T):
                S[i, t] = self.m.addVar(lb=0, vtype=GRB.CONTINUOUS, name='S' + '(' + str(i) + ',' + str(t) + ')')

        P = tupledict()
        for i in range(G):
            for t in range(T):
                P[i, t] = self.m.addVar(lb=0, ub=P_max[i], vtype=GRB.CONTINUOUS, name='P' + '(' + str(i) + ',' + str(t) + ')')

        theta = tupledict()
        for i in range(N):
            for t in range(T):
                theta[i, t] = self.m.addVar(vtype=GRB.CONTINUOUS, name='theta' + '(' + str(i) + ',' + str(t) + ')')

        P_ij = tupledict()
        for l in range(L):
            for t in range(T):
                P_ij[l, t] = self.m.addVar(lb=- P_ij_max[l], ub=P_ij_max[l], vtype=GRB.CONTINUOUS, name='P_ij' + '(' + str(l) + ',' + str(t) + ')')

        # 创建目标函数
        if MILP_flag == 0:
            original_cost = QuadExpr()
            original_cost += quicksum(u[i, t] * alpha[i] for i in range(G) for t in range(T))
            original_cost += quicksum(P[i, t] * beta[i] * 100 for i in range(G) for t in range(T))
            original_cost += quicksum(P[i, t] * P[i, t] * gamma[i] * 10000 for i in range(G) for t in range(T))
            original_cost += quicksum(S[i, t] for i in range(G) for t in range(T))
        else:
            original_cost = LinExpr()
            D = 4
            z_sup = tupledict()
            for i in range(G):
                for t in range(T):
                    z_sup[i, t] = self.m.addVar(lb=0, vtype=GRB.CONTINUOUS, name='z_sup' + '(' + str(i) + ',' + str(t) + ')')
            for l in range(D + 1):
                for i in range(G):
                    p_il = P_min[i] * 100 + l * (P_max[i] * 100 - P_min[i] * 100) / D
                    for t in range(T):
                        self.m.addConstr(z_sup[i, t] >= (2 * gamma[i] * p_il + beta[i]) * P[i, t] * 100 + (alpha[i] - gamma[i] * p_il * p_il) * u[i, t])
            original_cost += quicksum(z_sup[i, t] for i in range(G) for t in range(T))
            original_cost += quicksum(S[i, t] for i in range(G) for t in range(T))

        # 额外约束

        if search_space_reduction:
            if reduction1:
                # print(W)
                # sigmoid
                W_positive = np.maximum(W, 0.0)
                W_negative = np.minimum(W, 0.0)
                M1_min = b + W_negative.sum(axis=0)
                M1_max = b + W_positive.sum(axis=0)
                h = self.m.addVars(W.shape[0], lb=0, ub=1, vtype=GRB.CONTINUOUS, name="h")

                # tanh
                # M1_min = b - np.abs(W).sum(axis=0)
                # M1_max = b + np.abs(W).sum(axis=0)
                # h = self.m.addVars(W.shape[0], lb=-1, ub=1, vtype=GRB.CONTINUOUS, name="h")

                self.h = h
            if reduction2:
                penalty = LinExpr()

            for i in range(G):
                for t in range(T):
                    confidence_it = confidence_weights[i, t]
                    if reduction2:
                        if reduction1:
                            use_reduction2 = confidence_it <= 0.99
                        else:
                            use_reduction2 = confidence_it > 0.99

                        if use_reduction2:
                            logit_it = float(logits[i, t])

                            if logit_it >= 0:
                                penalty += logit_it * (1 - u[i, t])
                            else:
                                penalty += -logit_it * u[i, t]

                    if reduction1 and confidence_weights[i, t] > 0.99:
                        index = i * T + t
                        decoder_output = (quicksum(W[k, index] * h[k] for k in range(W.shape[0])) + b[index])
                        constr_lb = self.m.addConstr(decoder_output >= M1_min[index] * (1 - u[i, t]))
                        constr_ub = self.m.addConstr(decoder_output <= M1_max[index] * u[i, t])
                        self.reduction1_constr.extend([constr_lb, constr_ub])

                        self.reduction1_constr_info.append({
                            "i": i,
                            "t": t,
                            "confidence": float(confidence_weights[i, t]),
                            "lb": constr_lb,
                            "ub": constr_ub,
                            "active": True
                        })

        if reduction2:
            total_cost = original_cost + eta * penalty
        else:
            total_cost = original_cost

        self.m.setObjective(total_cost, GRB.MINIMIZE)
        print(len(self.reduction1_constr))




        # 添加约束

        # 开关机费用约束
        def f_init(i, t):
            temp_tau = t + 1 - min_off[i] - cold_su_t[i]
            if temp_tau <= 0:
                if max(0, - T_init[i]) < (abs(temp_tau - 1) + 1):
                    return 1
            return 0

        for i in range(G):
            for t in range(T):
                self.m.addConstr(S[i, t] >= hot_su_cost[i] * s[i, t])
        for i in range(G):
            for t in range(T):
                tau_init = max(t + 1 - min_off[i] - cold_su_t[i], 1)
                self.m.addConstr(S[i, t] >= cold_su_cost[i] * ((s[i, t] - quicksum(d[i, tau] for tau in range(tau_init - 1, t))) - f_init(i, t)))

        # 功率平衡约束
        for k in range(N):
            for t in range(T):
                connected_nodes = node_connections[k]
                P_gen = quicksum(P[i, t] for i in range(G) if unit_bus[i] == k)
                sum1 = quicksum(B_matrix[k, j] * (theta[k, t] - theta[j, t]) for j in connected_nodes)
                self.m.addConstr(P_gen - nodes_load_percentage_P[k, t] * P_D[t] - sum1 == 0)

        # 线路功率流约束
        for k in range(L):
            for t in range(T):
                self.m.addConstr(P_ij[k, t] >= -P_ij_max[k])
                self.m.addConstr(P_ij[k, t] <= P_ij_max[k])
        z = 0
        for k in lines:
            for t in range(T):
                self.m.addConstr(P_ij[z, t] == B_matrix[k[0] - 1, k[1] - 1] * (theta[k[0] - 1, t] - theta[k[1] - 1, t]))
            z += 1

        # 固定参考节点
        for t in range(T):
            self.m.addConstr(theta[balance_node - 1, t] == 0)

        # 机组功率约束
        for i in range(G):
            for t in range(T):
                self.m.addConstr(P[i, t] >= u[i, t] * P_min[i])
                self.m.addConstr(P[i, t] <= u[i, t] * P_max[i])

        # 爬坡约束
        for i in range(G):
            self.m.addConstr(P[i, 0] - P_init[i] <= u[i, 0] * (ramp_up[i] + P_min[i]) - unit_init_status[i] * P_min[i] + s[i, 0] * (su_ramp[i] - ramp_up[i] - P_min[i]))
            self.m.addConstr(P_init[i] - P[i, 0] <= unit_init_status[i] * (ramp_down[i] + P_min[i]) - u[i, 0] * P_min[i] + d[i, 0] * (sd_ramp[i] - ramp_down[i] - P_min[i]))
            for t in range(1, T):
                self.m.addConstr(P[i, t] - P[i, t-1] <= u[i, t] * (ramp_up[i] + P_min[i]) - u[i, t-1] * P_min[i] + s[i, t] * (su_ramp[i] - ramp_up[i] - P_min[i]))
                self.m.addConstr(P[i, t-1] - P[i, t] <= u[i, t-1] * (ramp_down[i] + P_min[i]) - u[i, t] * P_min[i] + d[i, t] * (sd_ramp[i] - ramp_down[i] - P_min[i]))

        # 最小开关机时间约束
        for i in range(G):
            U_i = max(0, min(T, unit_init_status[i] * (min_on[i] - T_init[i])))
            L_i = max(0, min(T, (1 - unit_init_status[i]) * (min_off[i] + T_init[i])))
            for t in range(U_i, T):
                self.m.addConstr(quicksum(s[i, k] for k in range(max(0, t + 1 - min_on[i]), t + 1)) <= u[i, t])
            for t in range(L_i, T):
                self.m.addConstr(quicksum(d[i, k] for k in range(max(0, t + 1 - min_off[i]), t + 1)) <= 1 - u[i, t])
            for t in range(U_i + L_i):
                self.m.addConstr(u[i, t] == unit_init_status[i])

        # 机组状态约束
        for i in range(G):
            t = 0
            self.m.addConstr((s[i, t] - d[i, t]) == (u[i, t] - unit_init_status[i]))
            for t in range(1, T):
                self.m.addConstr((s[i, t] - d[i, t]) == (u[i, t] - u[i, t - 1]))


        self.u = u
        self.s = s
        self.d = d
        self.S = S
        self.P = P
        self.theta = theta
        self.P_ij = P_ij

        self.G = G
        self.T = T

        self.original_cost_expr = original_cost
        if reduction2:
            self.soft_penalty_expr = penalty
        self.total_cost_expr = total_cost

        # 更新模型
        self.m.update()

    def relax_reduction1_by_threshold(self, new_threshold):
        removed_count = 0

        for info in self.reduction1_constr_info:
            if info["active"] and info["confidence"] <= new_threshold:
                self.m.remove(info["lb"])
                self.m.remove(info["ub"])
                info["active"] = False
                removed_count += 1

        self.m.update()

        return removed_count

    def myOptimize(self):
        # 累计所有求解尝试的时间和节点数
        total_runtime = 0.0
        total_node_count = 0.0
        print("初始约束阈值为 0.99")
        self.m.optimize()

        current_runtime = self.m.Runtime
        current_node_count = self.m.NodeCount

        total_runtime += current_runtime
        total_node_count += current_node_count

        if self.reduction1 and self.fallback:
            threshold = 0.99
            alpha = 0.5
            while self.m.Status in (GRB.INFEASIBLE, GRB.UNBOUNDED, GRB.INF_OR_UNBD):
                threshold = 1.0 - alpha * (1.0 - threshold)
                if threshold >= 1.0:
                    self.relax_reduction1_by_threshold(threshold)
                    print(
                        f"模型异常：删除全部的 reduction1 约束，重新求解。"
                    )
                    self.m.optimize()

                    current_runtime = self.m.Runtime
                    current_node_count = self.m.NodeCount

                    total_runtime += current_runtime
                    total_node_count += current_node_count
                    break
                removed_count = self.relax_reduction1_by_threshold(threshold)
                print(
                    f"模型异常：阈值提高至 {threshold:.6f}，"
                    f"删除 {removed_count} 个变量对应的 reduction1 约束，重新求解。"
                )

                if removed_count == 0:
                    continue

                self.m.optimize()

                current_runtime = self.m.Runtime
                current_node_count = self.m.NodeCount

                total_runtime += current_runtime
                total_node_count += current_node_count

        if self.m.Status in (GRB.INFEASIBLE, GRB.UNBOUNDED, GRB.INF_OR_UNBD):
            print("模型无法求解！")
            return [None] * 17

        u_values = []
        s_values = []
        d_values = []

        for i in range(self.G):
            u_temp = []
            s_temp = []
            d_temp = []
            for t in range(self.T):
                var1 = self.m.getVarByName(f'u({i},{t})')
                var2 = self.m.getVarByName(f's({i},{t})')
                var3 = self.m.getVarByName(f'd({i},{t})')
                u_temp.append(var1.X)
                s_temp.append(var2.X)
                d_temp.append(var3.X)
            u_values.append(u_temp)
            s_values.append(s_temp)
            d_values.append(d_temp)
        u_values = np.array(u_values)
        s_values = np.array(s_values)
        d_values = np.array(d_values)
        u_values = (u_values > 0.5).astype(np.int8)
        s_values = (s_values > 0.5).astype(np.int8)
        d_values = (d_values > 0.5).astype(np.int8)
        # 原目标函数值
        original_obj = self.original_cost_expr.getValue()
        print(original_obj)

        h = []
        for i in range(len(self.h)):
            h.append(self.h[i].X)
        print(h)

        # 惩罚值
        if self.reduction2:
            penalty_obj = self.soft_penalty_expr.getValue()
            print(penalty_obj)
        else:
            penalty_obj = 0

        # 总目标函数值
        total_obj = self.m.ObjVal

        # 求解时间
        runtime = total_runtime

        # 模型大小指标
        orig_rows = self.m.NumConstrs
        orig_cols = self.m.NumVars
        orig_nonzeros = self.m.NumNZs

        node_count = total_node_count

        self.m.reset()
        t0 = time.perf_counter()
        presolved = self.m.presolve()
        t1 = time.perf_counter()
        presolve_time = t1 - t0

        pres_rows = presolved.NumConstrs
        pres_cols = presolved.NumVars
        pres_nonzeros = presolved.NumNZs

        # 统计变量类型
        type_count = defaultdict(int)
        for var in presolved.getVars():
            vtype = var.VType
            type_count[vtype] += 1

        # 释放预处理模型资源
        presolved.dispose()

        continuous_num, binary_num = type_count.get('C', 0), type_count.get('B', 0)

        return u_values, s_values, d_values, original_obj, penalty_obj, total_obj, runtime, continuous_num, binary_num, orig_rows, orig_cols, orig_nonzeros, pres_rows, pres_cols, pres_nonzeros, presolve_time, node_count



