from pathlib import Path

import numpy as np
import joblib


def compare_results(Origin_dir, Acceleration_dir):
    """Compare runtime, search nodes, presolved variables, and relative cost change.

    Average acceleration is the arithmetic mean of valid instance-wise speedups.
    """

    origin = joblib.load(Origin_dir)
    Acceleration = joblib.load(Acceleration_dir)

    origin_solution_obj = np.array(origin["original_obj"], dtype=object)
    Acceleration_solution_obj = np.array(Acceleration["original_obj"], dtype=object)

    origin_nodes = np.array(origin["explored_node"], dtype=object)
    Acceleration_nodes = np.array(Acceleration["explored_node"], dtype=object)

    origin_optimize_time = np.array(origin["optimize_time"], dtype=object)
    Acceleration_optimize_time = np.array(Acceleration["optimize_time"], dtype=object)
    model_infer_time = np.array(Acceleration["model_infer_time"], dtype=object)

    n = min(
        len(origin_solution_obj),
        len(Acceleration_solution_obj),
        len(origin_nodes),
        len(Acceleration_nodes),
        len(origin_optimize_time),
        len(Acceleration_optimize_time),
        len(model_infer_time)
    )

    origin_solution_obj = origin_solution_obj[:n]
    Acceleration_solution_obj = Acceleration_solution_obj[:n]
    origin_nodes = origin_nodes[:n]
    Acceleration_nodes = Acceleration_nodes[:n]
    origin_optimize_time = origin_optimize_time[:n]
    Acceleration_optimize_time = Acceleration_optimize_time[:n]
    model_infer_time = model_infer_time[:n]

    def is_valid(x):
        if x is None:
            return False
        try:
            return np.isfinite(float(x))
        except (TypeError, ValueError):
            return False

    valid_mask = np.array([
        is_valid(origin_solution_obj[i])
        and is_valid(Acceleration_solution_obj[i])
        and is_valid(origin_nodes[i])
        and is_valid(Acceleration_nodes[i])
        and is_valid(origin_optimize_time[i])
        and is_valid(Acceleration_optimize_time[i])
        and is_valid(model_infer_time[i])
        and float(origin_solution_obj[i]) != 0
        for i in range(n)
    ])

    valid_num = np.sum(valid_mask)
    invalid_num = n - valid_num

    print("Total cases: ", n)
    print("Valid comparable cases: ", valid_num)
    print("Skipped infeasible/invalid cases: ", invalid_num)

    def variable_count(value):
        if isinstance(value, (bool, np.bool_)):
            return None
        try:
            count = float(value)
        except (TypeError, ValueError, OverflowError):
            return None
        if count >= 0 and count.is_integer():
            return count
        return None

    for variable_type in ("binary", "continuous"):
        key = f"{variable_type}_var_num"
        origin_counts = origin.get(key)
        acceleration_counts = Acceleration.get(key)
        pairs = []
        if origin_counts is not None and acceleration_counts is not None:
            for origin_value, acceleration_value in zip(origin_counts[:n], acceleration_counts[:n]):
                origin_count = variable_count(origin_value)
                acceleration_count = variable_count(acceleration_value)
                if origin_count is not None and acceleration_count is not None:
                    pairs.append((origin_count, acceleration_count))

        label = f"Presolved {variable_type} variables (paired cases: {len(pairs)}/{n})"
        if pairs:
            origin_mean, acceleration_mean = np.mean(pairs, axis=0)
            print(f"{label}: mean OG = {origin_mean:.2f}, mean SSR = {acceleration_mean:.2f}")
        else:
            print(f"{label}: no valid counts.")

    if valid_num == 0:
        print("No valid comparable cases.\n")
        return

    # 只保留可比较的可行算例
    origin_solution_obj = origin_solution_obj[valid_mask].astype(float)
    Acceleration_solution_obj = Acceleration_solution_obj[valid_mask].astype(float)

    origin_nodes = origin_nodes[valid_mask].astype(float)
    Acceleration_nodes = Acceleration_nodes[valid_mask].astype(float)

    origin_optimize_time = origin_optimize_time[valid_mask].astype(float)
    Acceleration_optimize_time = Acceleration_optimize_time[valid_mask].astype(float)
    model_infer_time = model_infer_time[valid_mask].astype(float)

    Acceleration_total_time = Acceleration_optimize_time + model_infer_time

    # CI is expressed in percent; negative values mean a lower cost than OG-SCUC.
    ci_percent = (
        (Acceleration_solution_obj - origin_solution_obj)
        / np.abs(origin_solution_obj)
        * 100
    )

    print(
        "Average optimize time of OG-SCUC: ",
        np.mean(origin_optimize_time),
        "\t",
        "Average optimize time of LA-SCUC: ",
        np.mean(Acceleration_total_time)
    )

    # Instance-wise speedup uses inference time plus all solver attempts.
    # Exclude invalid timings from ratios and make the denominator explicit.
    speedup_valid_mask = (
        (origin_optimize_time > 0)
        & (Acceleration_optimize_time >= 0)
        & (model_infer_time >= 0)
        & np.isfinite(Acceleration_total_time)
        & (Acceleration_total_time > 0)
    )
    speedup_case_num = int(np.sum(speedup_valid_mask))

    if speedup_case_num > 0:
        speedup_ratios = (
            origin_optimize_time[speedup_valid_mask]
            / Acceleration_total_time[speedup_valid_mask]
        )
        accelerated_num = int(np.sum(speedup_ratios > 1.0))

        # Equal weight per case: average the paired speedup ratios.
        print("Average acceleration ratio: ", np.mean(speedup_ratios))
        print(
            "Number of accelerated cases (speedup > 1): "
            f"{accelerated_num}/{speedup_case_num} "
            f"({100.0 * accelerated_num / speedup_case_num:.2f}%)"
        )
        print("Median acceleration ratio: ", np.median(speedup_ratios))
        print("Maximum acceleration ratio: ", np.max(speedup_ratios))
        print("Minimum acceleration ratio: ", np.min(speedup_ratios))
    else:
        print("No valid positive-time cases for instance-wise speedup statistics.")

    if speedup_case_num < valid_num:
        print(
            "Cases excluded from instance-wise speedup statistics due to invalid timings: ",
            int(valid_num) - speedup_case_num
        )

    print(
        "Average nodes of OG-SCUC: ",
        np.mean(origin_nodes),
        "\t",
        "Average nodes of LA-SCUC: ",
        np.mean(Acceleration_nodes)
    )

    print("Number of CI <= 0.01%: ", np.sum(ci_percent <= 0.01))
    print("Number of CI <= 0.05%: ", np.sum(ci_percent <= 0.05))
    print("Number of CI <= 0.1%: ", np.sum(ci_percent <= 0.1))

    print("\n")

if __name__ == "__main__":
    results_dir = Path(__file__).resolve().parent


    print("====================IEEE-118====================")
    print("\n")

    # 118
    Origin_dir = results_dir / "DC_SCUC_118/Origin_Optimization_info_MILP_118.pkl"

    Acceleration_dir = results_dir / "DC_SCUC_118/dimension[1]_only_redution1_info_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_118/dimension[2]_only_redution1_info_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_118/dimension[4]_only_redution1_info_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_118/dimension[8]_only_redution1_info_MILP_118.pkl"
    compare_results(Origin_dir, Acceleration_dir)


    print("====================IEEE-354====================")
    print("\n")

    # 354
    Origin_dir = results_dir / "DC_SCUC_354/Origin_Optimization_info_MILP_354.pkl"

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[1]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[2]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[4]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[8]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    print("====================SCUC-354-fallback=====================")

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[1]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[2]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[4]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[8]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    print("====================IEEE-1062====================")
    print("\n")

    Origin_dir = results_dir / "DC_SCUC_1062/Origin_Optimization_info_MILP_1062.pkl"

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[1]_only_redution1_info_MILP_1062.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[2]_only_redution1_info_MILP_1062.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[4]_only_redution1_info_MILP_1062.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[8]_only_redution1_info_MILP_1062.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    print("====================IEEE-1062-fallback====================")
    print("\n")

    Origin_dir = results_dir / "DC_SCUC_1062/Origin_Optimization_info_MILP_1062.pkl"

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[1]_only_redution1_info_MILP_1062_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[2]_only_redution1_info_MILP_1062_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[4]_only_redution1_info_MILP_1062_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_1062/dimension[8]_only_redution1_info_MILP_1062_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    print("====================Ablation-Study====================")
    print("\n")
    print("\n")

    print("====================IEEE-354====================")
    print("\n")

    Origin_dir = results_dir / "DC_SCUC_354/Origin_Optimization_info_MILP_354.pkl"

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[1]_[0.95]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[2]_[0.95]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[4]_[0.95]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[8]_[0.95]_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    print("====================IEEE-354-fallback====================")
    print("\n")

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[1]_[0.95]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[2]_[0.95]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[4]_[0.95]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[8]_[0.95]_only_redution1_info_MILP_354_fallback.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    print("====================IEEE-354-full====================")
    print("\n")

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[1]_full_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[2]_full_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[4]_full_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)

    Acceleration_dir = results_dir / "DC_SCUC_354/dimension[8]_full_only_redution1_info_MILP_354.pkl"
    compare_results(Origin_dir, Acceleration_dir)




