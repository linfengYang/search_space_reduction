from solver.DC_SCUC_Gurobi_model import DC_SCUC_Gurobi_model
import numpy as np
import torch
import time
from utlis.read_dataset import read_dataset_from_txt
import joblib
from utlis.MSC_LSTM_model_predict import predict_u_by_model
from run.model.MSC_LSTM import *
from run.model.LCD_AE import *

def myrun(search_space_reduction, reduction1, reduction2, eta, file_name, LCD_AE_model_path, latent_dim):
    # 参数获取
    G = int(486)
    N = int(1062)
    T = int(24)
    L = int(1686)
    # 获取机组参数
    from utlis.get_486_1062_data import get_data
    data = get_data("/home/huangboyang/Learning-based-optimization/utlis/SCUC1062.txt")

    # 记录数据
    optimize_time = []
    original_obj = []
    penalty_obj = []
    total_obj = []
    u_values = []
    continuous_var_num = []
    binary_var_num = []
    orig_rows = []
    orig_cols = []
    orig_nonzeros = []
    pres_rows = []
    pres_cols = []
    pres_nonzeros = []
    presolve_time = []
    model_infer_time = []
    explored_node = []

    # 设置求解停止间隙
    MIPGap = 0.0001
    # 是否线性化
    MILP_flag = 1

    # 加载模型
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    model_path = "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_1062/MSC_LSTM[1062]_Epoch[148]_TrainingLoss[0.028569]_ValidationLoss[0.032840].pth"
    dataset_test_dir = "/home/huangboyang/Learning-based-optimization/dataset/DC_SCUC_486_1062/test"
    MSC_LSTM_scaler = joblib.load("/home/huangboyang/Learning-based-optimization/scaler/MSC_LSTM_system_load_scaler_1062.pkl")
    X, _ = read_dataset_from_txt(dataset_test_dir, G, N)

    my_model = MSCLSTM_U(num_units=G, input_channels=N + 1)
    my_model.load_state_dict(torch.load(model_path, map_location=device))
    my_model.to(device)
    my_model.eval()

    LCD_AE_model = LCD_AE(
        num_units=G,
        latent_dim=latent_dim
    )
    LCD_AE_model.load_state_dict(torch.load(LCD_AE_model_path, map_location=device))
    LCD_AE_model.to(device)
    LCD_AE_model.eval()

    LCD_AE_scaler = joblib.load("/home/huangboyang/Learning-based-optimization/scaler/LCD_AE_system_load_scaler_1062.pkl")

    for i in range(X.shape[0]):
        P_D = (X[i, 0, :]).copy()
        nodes_load_P = X[i, 1:, :]
        hourly_sum = nodes_load_P.sum(axis=0, keepdims=True)
        nodes_load_percentage_P = nodes_load_P / hourly_sum

        theta = LCD_AE_scaler.transform(P_D.reshape(-1, 1)).reshape(1, T)
        theta = np.concatenate([theta, nodes_load_percentage_P], axis=0).astype(np.float32)
        theta = torch.from_numpy(theta).float().unsqueeze(0).to(device)

        model_infer_start = time.perf_counter()
        with torch.no_grad():
            W, b = LCD_AE_model.generate_effective_parameters(theta)

            # 去掉batch维，并转换为Gurobi便于使用的NumPy数组
            W = W.squeeze(0).cpu().numpy().astype(np.float64)
            b = b.squeeze(0).cpu().numpy().astype(np.float64)

        logits, confidence_weights = predict_u_by_model(
            P_D_raw=P_D,
            nodes_load_percentage_P=nodes_load_percentage_P,
            model=my_model,
            scaler=MSC_LSTM_scaler,
            device=device,
            threshold=0.5
        )
        model_infer_end = time.perf_counter()

        DC_SCUC = DC_SCUC_Gurobi_model(G, N, T, L, data["alpha"], data["beta"], data["gamma"],
                                       data["hot_su_cost"], data["cold_su_cost"],
                                       data["min_on"], data["min_off"], data["cold_su_t"], data["P_max"],
                                       data["P_min"], data["ramp_up"], data["ramp_down"], data["su_ramp"],
                                       data["sd_ramp"],
                                       data["unit_init_status"], data["T_init"], data["node_connections"],
                                       nodes_load_percentage_P, data["lines"], data["P_ij_max"],
                                       data["B_matrix"],
                                       P_D * 0.01, data["P_init"], data["unit_bus"], data["balance_node"], MIPGap,
                                       MILP_flag, W=W, b=b, eta=eta, logits=logits, confidence_weights=confidence_weights,
                                       search_space_reduction=search_space_reduction, reduction1=reduction1, reduction2=reduction2)
        u1, s1, d1, original_obj1, penalty_obj1, total_obj1, t1, continuous_var_num1, binary_var_num1, orig_rows1, orig_cols1, orig_nonzeros1, pres_rows1, pres_cols1, pres_nonzeros1, presolve_time1, node_count = DC_SCUC.myOptimize()
        u_values.append(u1)
        original_obj.append(original_obj1)
        penalty_obj.append(penalty_obj1)
        total_obj.append(total_obj1)
        optimize_time.append(t1)
        model_infer_time.append(model_infer_end - model_infer_start)
        continuous_var_num.append(continuous_var_num1)
        binary_var_num.append(binary_var_num1)
        orig_rows.append(orig_rows1)
        orig_cols.append(orig_cols1)
        orig_nonzeros.append(orig_nonzeros1)
        pres_rows.append(pres_rows1)
        pres_cols.append(pres_cols1)
        pres_nonzeros.append(pres_nonzeros1)
        presolve_time.append(presolve_time1)
        explored_node.append(node_count)

    from utlis.save_result import save_results

    # 保存结果, 根据需要修改名字
    name = file_name
    save_results(u_values, original_obj, penalty_obj, total_obj, optimize_time, model_infer_time, continuous_var_num, binary_var_num,
                 orig_rows, orig_cols,
                 orig_nonzeros, pres_rows, pres_cols, pres_nonzeros, presolve_time, explored_node, name,
                 output_dir="/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_1062")

if __name__ == '__main__':
    info_set = [
        # {
        #     "eta": 0.0,
        #     "search_space_reduction": True,
        #     "reduction1": True,
        #     "reduction2": False,
        #     "file_name": "dimension[1]_only_redution1_info_MILP_1062",
        #     "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_1062/LCD-AE[1062-1]_Epoch[179]_TrainingLoss[0.033920]_ValidationLoss[0.036593].pth",
        #     "latent_dim": 1
        # },
        # {
        #     "eta": 0.0,
        #     "search_space_reduction": True,
        #     "reduction1": True,
        #     "reduction2": False,
        #     "file_name": "dimension[2]_only_redution1_info_MILP_1062",
        #     "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_1062/LCD-AE[1062-2]_Epoch[146]_TrainingLoss[0.035009]_ValidationLoss[0.036599].pth",
        #     "latent_dim": 2
        # },
        # {
        #     "eta": 0.0,
        #     "search_space_reduction": True,
        #     "reduction1": True,
        #     "reduction2": False,
        #     "file_name": "dimension[4]_only_redution1_info_MILP_1062",
        #     "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_1062/LCD-AE[1062-4]_Epoch[161]_TrainingLoss[0.034285]_ValidationLoss[0.036629].pth",
        #     "latent_dim": 4
        # },
        # {
        #     "eta": 0.0,
        #     "search_space_reduction": True,
        #     "reduction1": True,
        #     "reduction2": False,
        #     "file_name": "dimension[8]_only_redution1_info_MILP_1062",
        #     "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_1062/LCD-AE[1062-8]_Epoch[137]_TrainingLoss[0.034496]_ValidationLoss[0.036747].pth",
        #     "latent_dim": 8
        # },
        {
            "eta": 0.0,
            "search_space_reduction": False,
            "reduction1": False,
            "reduction2": False,
            "file_name": "Origin_Optimization_info_MILP_1062",
            "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_1062/LCD-AE[1062-4]_Epoch[161]_TrainingLoss[0.034285]_ValidationLoss[0.036629].pth",
            "latent_dim": 4
        }
    ]

    for info in info_set:
        myrun(
            search_space_reduction=info["search_space_reduction"],
            reduction1=info["reduction1"],
            reduction2=info["reduction2"],
            eta=info["eta"],
            file_name=info["file_name"],
            LCD_AE_model_path=info["LCD_AE_model_path"],
            latent_dim=info["latent_dim"]
        )

        print(f"实验完成: {info['file_name']}\n")