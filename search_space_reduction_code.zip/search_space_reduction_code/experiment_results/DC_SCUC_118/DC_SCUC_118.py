from solver.DC_SCUC_Gurobi_model import DC_SCUC_Gurobi_model
import numpy as np
import torch
import time
from utlis.read_dataset import read_dataset_from_txt
import joblib
from utlis.MSC_LSTM_model_predict import predict_u_by_model
from run.model.MSC_LSTM import *
from run.model.LCD_AE import *

def myrun(search_space_reduction, reduction1, reduction2, eta, file_name, LCD_AE_model_path, latent_dim):
    # 参数获取
    G = int(54)
    N = int(118)
    T = int(24)
    L = int(186)
    # 获取机组参数
    from utlis.get_54_118_data import get_data

    data = get_data(G, N)
    # 基准负荷
    data["P_D"] = np.array([4200, 3960, 3480, 2400, 3000, 3600, 4200, 4680, 4920, 5280, 5340, 5040,
                            4800, 4560, 5280, 5400, 5100, 5340, 5640, 5880, 6000, 5400, 5220, 4920], dtype=np.float32)

    # 记录数据
    optimize_time = []
    original_obj = []
    penalty_obj = []
    total_obj = []
    u_values = []
    continuous_var_num = []
    binary_var_num = []
    orig_rows = []
    orig_cols = []
    orig_nonzeros = []
    pres_rows = []
    pres_cols = []
    pres_nonzeros = []
    presolve_time = []
    model_infer_time = []
    explored_node = []

    # 设置求解停止间隙
    MIPGap = 0.0001
    # 是否线性化
    MILP_flag = 1

    # 加载模型
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    model_path = "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_118/MSC_LSTM[118]_Epoch[698]_TrainingLoss[0.030994]_ValidationLoss[0.030267].pth"
    dataset_test_dir = "/home/huangboyang/Learning-based-optimization/dataset/DC_SCUC_54_118/test"
    MSC_LSTM_scaler = joblib.load("/home/huangboyang/Learning-based-optimization/scaler/MSC_LSTM_system_load_scaler_118.pkl")
    X, _ = read_dataset_from_txt(dataset_test_dir, G, N)

    my_model = MSCLSTM_S(num_units=G, input_channels=N + 1)
    my_model.load_state_dict(torch.load(model_path, map_location=device))
    my_model.to(device)
    my_model.eval()

    LCD_AE_model = LCD_AE(
    num_units=G,
    latent_dim=latent_dim
)
    LCD_AE_model.load_state_dict(torch.load(LCD_AE_model_path, map_location=device))
    LCD_AE_model.to(device)
    LCD_AE_model.eval()

    LCD_AE_scaler = joblib.load("/home/huangboyang/Learning-based-optimization/scaler/LCD_AE_system_load_scaler_118.pkl")

    for i in range(X.shape[0]):
        P_D = (X[i, 0, :]).copy()
        nodes_load_P = X[i, 1:, :]
        hourly_sum = nodes_load_P.sum(axis=0, keepdims=True)
        nodes_load_percentage_P = nodes_load_P / hourly_sum

        theta = LCD_AE_scaler.transform(P_D.reshape(-1, 1)).reshape(1, T)
        theta = np.concatenate([theta, nodes_load_percentage_P], axis=0).astype(np.float32)
        theta = torch.from_numpy(theta).float().unsqueeze(0).to(device)

        model_infer_start = time.perf_counter()
        with torch.no_grad():

            W, b = LCD_AE_model.generate_effective_parameters(theta)

            # 去掉batch维，并转换为Gurobi便于使用的NumPy数组
            W = W.squeeze(0).cpu().numpy().astype(np.float64)
            b = b.squeeze(0).cpu().numpy().astype(np.float64)

        logits, confidence_weights = predict_u_by_model(
            P_D_raw=P_D,
            nodes_load_percentage_P=nodes_load_percentage_P,
            model=my_model,
            scaler=MSC_LSTM_scaler,
            device=device,
            threshold=0.5
        )
        model_infer_end = time.perf_counter()

        DC_SCUC = DC_SCUC_Gurobi_model(G, N, T, L, data["alpha"], data["beta"], data["gamma"],
                                       data["hot_su_cost"], data["cold_su_cost"],
                                       data["min_on"], data["min_off"], data["cold_su_t"], data["P_max"],
                                       data["P_min"], data["ramp_up"], data["ramp_down"], data["su_ramp"],
                                       data["sd_ramp"],
                                       data["unit_init_status"], data["T_init"], data["node_connections"],
                                       nodes_load_percentage_P, data["lines"], data["P_ij_max"],
                                       data["B_matrix"],
                                       P_D * 0.01, data["P_init"], data["unit_bus"], data["balance_node"], MIPGap, MILP_flag, W=W, b=b,
                                       eta=eta, logits=logits, confidence_weights=confidence_weights, search_space_reduction=search_space_reduction,
                                       reduction1=reduction1, reduction2=reduction2)
        u1, s1, d1, original_obj1, penalty_obj1, total_obj1, t1, continuous_var_num1, binary_var_num1, orig_rows1, orig_cols1, orig_nonzeros1, pres_rows1, pres_cols1, pres_nonzeros1, presolve_time1, node_count = DC_SCUC.myOptimize()
        u_values.append(u1)
        original_obj.append(original_obj1)
        penalty_obj.append(penalty_obj1)
        total_obj.append(total_obj1)
        optimize_time.append(t1)
        model_infer_time.append(model_infer_end - model_infer_start)
        continuous_var_num.append(continuous_var_num1)
        binary_var_num.append(binary_var_num1)
        orig_rows.append(orig_rows1)
        orig_cols.append(orig_cols1)
        orig_nonzeros.append(orig_nonzeros1)
        pres_rows.append(pres_rows1)
        pres_cols.append(pres_cols1)
        pres_nonzeros.append(pres_nonzeros1)
        presolve_time.append(presolve_time1)
        explored_node.append(node_count)

    from utlis.save_result import save_results

    # 保存结果, 根据需要修改名字
    name = file_name
    save_results(u_values, original_obj, penalty_obj, total_obj, optimize_time, model_infer_time, continuous_var_num, binary_var_num,
                 orig_rows, orig_cols,
                 orig_nonzeros, pres_rows, pres_cols, pres_nonzeros, presolve_time, explored_node, name,
                 output_dir="/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_118")


if __name__ == '__main__':
    info_set = [
        {
            "eta": 0.0,
            "search_space_reduction": True,
            "reduction1": True,
            "reduction2": False,
            "file_name": "dimension[1]_only_redution1_info_MILP_118",
            "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_118/LCD-AE[118-1]_Epoch[732]_TrainingLoss[0.036763]_ValidationLoss[0.035182].pth",
            "latent_dim": 1
        },
        {
            "eta": 0.0,
            "search_space_reduction": True,
            "reduction1": True,
            "reduction2": False,
            "file_name": "dimension[2]_only_redution1_info_MILP_118",
            "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_118/LCD-AE[118-2]_Epoch[490]_TrainingLoss[0.036942]_ValidationLoss[0.035257].pth",
            "latent_dim": 2
        },
        {
            "eta": 0.0,
            "search_space_reduction": True,
            "reduction1": True,
            "reduction2": False,
            "file_name": "dimension[4]_only_redution1_info_MILP_118",
            "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_118/LCD-AE[118-4]_Epoch[723]_TrainingLoss[0.035629]_ValidationLoss[0.034499].pth",
            "latent_dim": 4
        },
        {
            "eta": 0.0,
            "search_space_reduction": True,
            "reduction1": True,
            "reduction2": False,
            "file_name": "dimension[8]_only_redution1_info_MILP_118",
            "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_118/LCD-AE[118-8]_Epoch[651]_TrainingLoss[0.034037]_ValidationLoss[0.033728].pth",
            "latent_dim": 8
        },
        {
            "eta": 0.0,
            "search_space_reduction": False,
            "reduction1": False,
            "reduction2": False,
            "file_name": "Origin_Optimization_info_MILP_118",
            "LCD_AE_model_path": "/home/huangboyang/Learning-based-optimization/experiment_results/DC_SCUC_118/LCD-AE[118-4]_Epoch[723]_TrainingLoss[0.035629]_ValidationLoss[0.034499].pth",
            "latent_dim": 4
        }
    ]

    for info in info_set:

        myrun(
            search_space_reduction=info["search_space_reduction"],
            reduction1=info["reduction1"],
            reduction2=info["reduction2"],
            eta=info["eta"],
            file_name=info["file_name"],
            LCD_AE_model_path=info["LCD_AE_model_path"],
            latent_dim=info["latent_dim"]
        )

        print(f"实验完成: {info['file_name']}\n")