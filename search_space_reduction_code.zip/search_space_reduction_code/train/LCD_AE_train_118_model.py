import torch
from utlis.read_dataset import read_dataset_from_txt
from utlis.create_dataset import UCLoadDataset
from torch.utils.data import DataLoader
from run.model.LCD_AE import *
from run.LCD_AE_trainer import trainer
from utlis.pre_processing_trainning_data import pre_processing_data
from utlis.set_seed import set_seed

# 固定随机种子，默认42
set_seed(42, deterministic=False)  # deterministic参数可选，是否使用确定性算法

num_units = 54
num_nodes = 118
system_load_scaler_save_dir = "/home/huangboyang/Learning-based-optimization/scaler/LCD_AE_system_load_scaler_118.pkl"

# 读取数据
dataset_train_dir = "/home/huangboyang/Learning-based-optimization/dataset/DC_SCUC_54_118/train"
dataset_val_dir = "/home/huangboyang/Learning-based-optimization/dataset/DC_SCUC_54_118/val"

X_train, Y_train = read_dataset_from_txt(dataset_train_dir, num_units, num_nodes)
X_val, Y_val = read_dataset_from_txt(dataset_val_dir, num_units, num_nodes)

# 数据预处理
X_train_scaled, X_val_scaled = pre_processing_data(X_train, X_val, system_load_scaler_save_dir)

# 创建Dataset实例
train_dataset = UCLoadDataset(X_train_scaled, Y_train)
val_dataset = UCLoadDataset(X_val_scaled, Y_val)
# 创建DataLoader
batch_size = 128
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)


model = LCD_AE(
    num_units=54,
    latent_dim=8
)
device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
model.to(device)

# 超参数
epochs = 1000
patience = 30
clip = 1.0
warmup = 50
lr = 1e-3
loss_fn = BCEW_TS_Loss(lambda_smooth=0.005)  # 建议lambda_smooth取值0.001至0.01
optimizer = torch.optim.Adam(model.parameters(), lr=lr)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=int(epochs - warmup), eta_min=1e-6)

my_trainer = trainer(model, loss_fn, optimizer, scheduler, device, patience, epochs, clip, warmup)
my_trainer.train(train_loader, val_loader)